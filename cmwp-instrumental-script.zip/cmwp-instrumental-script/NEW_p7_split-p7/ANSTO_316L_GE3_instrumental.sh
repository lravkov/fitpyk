#!/bin/bash

#./split_pearson7_instr_NEW_windows peak_position left_hwhm right_hwhm left_shape right_shape number_of_datapoints MAX_value_of_deltaK

./split_pearson7_instr_NEW_windows 5.223 0.005848 0.0057467 3.2426566 2.4528957 500 0.1
./split_pearson7_instr_NEW_windows 6.044 0.0062772 0.0064068 2.6168219 2.6759464 500 0.1
./split_pearson7_instr_NEW_windows 8.56 0.0070979 0.0069286 4.1604654 3.1934075 500 0.1
./split_pearson7_instr_NEW_windows 10.027 0.0080296 0.0082911 3.834649 3.7502389 500 0.1
./split_pearson7_instr_NEW_windows 10.464 0.00781 0.0079863 3.8808145 3.6813793 500 0.1
./split_pearson7_instr_NEW_windows 12.106 0.0095288 0.0099493 3.8779708 4.1235269 500 0.1
