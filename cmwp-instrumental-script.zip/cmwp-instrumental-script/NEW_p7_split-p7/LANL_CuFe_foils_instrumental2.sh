#!/bin/bash

#./split_pearson7_instr_NEW_windows peak_position left_hwhm right_hwhm left_shape right_shape number_of_datapoints MAX_value_of_deltaK

./split_pearson7_instr_NEW_windows 13.53 0.008795352598932948 -0.006588030704464318 1.517636961425004 1.4895122656500033 500 0.1
./split_pearson7_instr_NEW_windows 13.95 0.008781057089210075 -0.006782343946092 1.517636961425004 1.4895122656500033 500 0.1
