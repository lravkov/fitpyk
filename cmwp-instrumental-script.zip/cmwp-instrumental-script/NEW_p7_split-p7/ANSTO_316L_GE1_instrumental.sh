#!/bin/bash

#./split_pearson7_instr_NEW_windows peak_position left_hwhm right_hwhm left_shape right_shape number_of_datapoints MAX_value_of_deltaK

./split_pearson7_instr_NEW_windows 5.223 0.0062098 0.0058452 2.5741522 2.290753 500 0.1
./split_pearson7_instr_NEW_windows 6.044 0.0066792 0.0067798 2.9093647 2.6329476 500 0.1
./split_pearson7_instr_NEW_windows 8.56 0.0072925 0.0070407 4.2986915 3.2188793 500 0.1
./split_pearson7_instr_NEW_windows 10.027 0.0080296 0.0082911 3.834649 3.750239 500 0.1
./split_pearson7_instr_NEW_windows 10.464 0.0079108 0.0079672 4.0144618 4.272198 500 0.1
./split_pearson7_instr_NEW_windows 12.106 0.0097957 0.0100984 4.5077489 3.698075 500 0.1
