#!/bin/bash

#./split_pearson7_instr_NEW_windows peak_position left_hwhm right_hwhm left_shape right_shape number_of_datapoints MAX_value_of_deltaK

./split_pearson7_instr_NEW_windows 5.223 0.0061913 0.0059589 3.615898 2.2570824 500 0.1
./split_pearson7_instr_NEW_windows 6.044 0.0068991 0.0071875 2.9488556 2.6621804 500 0.1
./split_pearson7_instr_NEW_windows 8.56 0.0073061 0.0072516 3.1503169 3.1107972 500 0.1
./split_pearson7_instr_NEW_windows 10.027 0.0080036 0.0080844 3.8424788 3.4507996 500 0.1
./split_pearson7_instr_NEW_windows 10.464 0.0078056 0.0080401 4.1275932 3.7210359 500 0.1
./split_pearson7_instr_NEW_windows 12.106 0.0095288 0.0099493 3.8779708 4.1235269 500 0.1
